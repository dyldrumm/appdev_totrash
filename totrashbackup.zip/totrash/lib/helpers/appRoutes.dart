class Approutes {
  static final String homescreen = "/homeScreen";
  static final String datascreen = "/enterData";
}
