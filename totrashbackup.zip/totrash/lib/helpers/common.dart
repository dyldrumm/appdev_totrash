class Common {
  static final String assetImages = "assets/images/";
}
